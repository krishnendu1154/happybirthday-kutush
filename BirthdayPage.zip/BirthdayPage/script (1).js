var a = prompt("Enter UserName");
var b = prompt("Enter password");
if (a == "pramalika" && b == "bacchha") {
    window.location.href = "start.html";
} else {
    alert("invalid details");
    window.location.href = "index.html";
}